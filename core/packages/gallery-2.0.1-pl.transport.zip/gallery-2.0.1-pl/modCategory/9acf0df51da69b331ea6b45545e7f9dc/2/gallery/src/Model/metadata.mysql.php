<?php
$xpdo_meta_map = array (
    'version' => '3.0',
    'namespace' => 'Gallery\\Model',
    'namespacePrefix' => 'Gallery',
    'class_map' => 
    array (
        'MODX\\Revolution\\Sources\\modMediaSource' => 
        array (
            0 => 'Gallery\\Model\\GalleryAlbumsMediaSource',
        ),
    ),
);