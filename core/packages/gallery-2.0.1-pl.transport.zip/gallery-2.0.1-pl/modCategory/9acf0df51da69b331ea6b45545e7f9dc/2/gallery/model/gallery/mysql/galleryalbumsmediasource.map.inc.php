<?php
/**
 * @package gallery
 */
$xpdo_meta_map['GalleryAlbumsMediaSource']= array (
  'package' => 'gallery',
  'version' => NULL,
  'extends' => 'modMediaSource',
  'tableMeta' => 
  array (
    'engine' => 'MyISAM',
  ),
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
